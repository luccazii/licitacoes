<?php
  include_once("classes/usuario.class.php");
  include_once("classes/licitacaoControle.class.php");
  include_once("classes/historicoControle.class.php");
  session_start();
  if(!isset($_SESSION['id'])){
    header('location: index.php?erro=2');
  }
    $usuario = unserialize($_SESSION['user']);
    $bd = new bd();
        $linhas = $bd->executa ("SELECT * FROM proposta WHERE idfornecedor = '".$usuario->getId()."' ");
        foreach($linhas as $linha){
        	$idl = $linha['idlicitacao'];
        	$licita = $bd->executa ("SELECT * FROM licitacoes WHERE idlicitacao = '".$idl."' ");
        	?>
        		<table id="table_id" class="display">
            <thead>
              <tr>
                <th>Data</th>
                <th>Edital</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php
        	foreach ($licita as $lic) {
        		
              echo "<tr>";
               echo "<td width='150px'>".$lic['data']."</td>";
               echo "<td width='90px'>".$lic['edital']."</td>";
               echo "<td width='90px'>".$lic['status']."</td>";
               echo "</tr>";
              ?>
            </tbody>
          </table>
          <?php
        	}
        }
        

        if($linhas->num_rows == '0'){
       echo "<p> Ainda não há licitações cadastradas.</p>";
      die;
    }